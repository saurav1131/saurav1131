package in.cdac.bean;



public class RatingAndReview {
	private int review_id;
	private String review_text;
	private int overall_rating;
	private String submitted_by;
	
	
	
	public RatingAndReview() {
		super();
		// TODO Auto-generated constructor stub
	}


	public RatingAndReview(int review_id, String review_text, int overall_rating, String submitted_by) {
		super();
		this.review_id = review_id;
		this.review_text = review_text;
		this.overall_rating = overall_rating;
		this.submitted_by = submitted_by;
	}


	public RatingAndReview(String review_text, int overall_rating, String submitted_by) {
		super();
		this.review_text = review_text;
		this.overall_rating = overall_rating;
		this.submitted_by = submitted_by;
	}


	public RatingAndReview(int review_id, String review_text, int overall_rating) {
		super();
		this.review_id = review_id;
		this.review_text = review_text;
		this.overall_rating = overall_rating;
	}


	public RatingAndReview(int review_id) {
		super();
		this.review_id = review_id;
	}


	public int getReview_id() {
		return review_id;
	}


	public void setReview_id(int review_id) {
		this.review_id = review_id;
	}


	public String getReview_text() {
		return review_text;
	}


	public void setReview_text(String review_text) {
		this.review_text = review_text;
	}


	public int getOverall_rating() {
		return overall_rating;
	}


	public void setOverall_rating(int overall_rating) {
		this.overall_rating = overall_rating;
	}


	public String getSubmitted_by() {
		return submitted_by;
	}


	public void setSubmitted_by(String submitted_by) {
		this.submitted_by = submitted_by;
	}
	
	
}
