package in.cdac.bean;


import java.sql.Date;

public class AnnouncementUser {
    private int announcement_id;
	private String announcement_title;
	private String announcement_msg;
	private Date announcement_start_date;
	private Date announcement_end_date;
	private String submitted_by ;
	public int getAnnouncement_id;
	
	
	
	
	public AnnouncementUser() {
		super();
	}


	public AnnouncementUser(String announcement_title, String announcement_msg, Date announcement_start_date,
			Date announcement_end_date,String submitted_by) {
		super();
		
		this.announcement_title = announcement_title;
		this.announcement_msg = announcement_msg;
		this.announcement_start_date = announcement_start_date;
		this.announcement_end_date = announcement_end_date;
		this.submitted_by = submitted_by;
		
	}
	
	


	public AnnouncementUser(int announcement_id, String announcement_title, String announcement_msg, Date announcement_start_date,
			Date announcement_end_date) {
		super();
		this.announcement_id = announcement_id;
		this.announcement_title = announcement_title;
		this.announcement_msg = announcement_msg;
		this.announcement_start_date = announcement_start_date;
		this.announcement_end_date = announcement_end_date;
		//this.submitted_by = submitted_by;
		//this.getAnnouncement_id = getAnnouncement_id;
	}


	public int getAnnouncement_id() {
		return announcement_id;
	}


	public void setAnnouncement_id(int announcement_id) {
		this.announcement_id = announcement_id;
	}


	public String getAnnouncement_title() {
		return announcement_title;
	}


	public void setAnnouncement_title(String announcement_title) {
		this.announcement_title = announcement_title;
	}


	public String getAnnouncement_msg() {
		return announcement_msg;
	}


	public void setAnnouncement_msg(String announcement_msg) {
		this.announcement_msg = announcement_msg;
	}


	public Date getAnnouncement_start_date() {
		return announcement_start_date;
	}


	public void setAnnouncement_start_date(Date announcement_start_date) {
		this.announcement_start_date = announcement_start_date;
	}


	public Date getAnnouncement_end_date() {
		return announcement_end_date;
	}


	public void setAnnouncement_end_date(Date announcement_end_date) {
		this.announcement_end_date = announcement_end_date;
	}


	public String getSubmitted_by() {
		return submitted_by;
	}


	public void setSubmitted_by(String submitted_by) {
		this.submitted_by = submitted_by;
	}


	public int getGetAnnouncement_id() {
		return getAnnouncement_id;
	}


	public void setGetAnnouncement_id(int getAnnouncement_id) {
		this.getAnnouncement_id = getAnnouncement_id;
	}

	
	
}
