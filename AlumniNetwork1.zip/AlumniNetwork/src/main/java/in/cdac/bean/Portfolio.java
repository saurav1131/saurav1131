package in.cdac.bean;

public class Portfolio {
	private int portfolio_id ;
	private String name;
	private String photo_id;
	private String personaldetails;
	private String qualifications;
	private String projects;
	private String certification;
	private String paperspublished;
	private String location;
	private String submitted_by;
	
	
	
	
	public Portfolio(int portfolio_id, String name, String photo_id, String personaldetails, String qualifications,
			String projects, String certification, String paperpublished, String location, String submitted_by) {
		super();
		this.portfolio_id = portfolio_id;
		this.name = name;
		this.photo_id = photo_id;
		this.personaldetails = personaldetails;
		this.qualifications = qualifications;
		this.projects = projects;
		this.certification = certification;
		this.paperspublished = paperpublished;
		this.location = location;
		this.submitted_by = submitted_by;
	}




	public Portfolio(String name, String photo_id, String personaldetails, String qualifications, String projects,
			String certification, String paperpublished, String location, String submitted_by) {
		super();
		this.name = name;
		this.photo_id = photo_id;
		this.personaldetails = personaldetails;
		this.qualifications = qualifications;
		this.projects = projects;
		this.certification = certification;
		this.paperspublished = paperpublished;
		this.location = location;
		this.submitted_by = submitted_by;
	}




	public Portfolio(int portfolio_id, String name, String photo_id, String personaldetails, String qualifications,
			String projects, String certification, String paperspublished, String location) {
		super();
		this.portfolio_id = portfolio_id;
		this.name = name;
		this.photo_id = photo_id;
		this.personaldetails = personaldetails;
		this.qualifications = qualifications;
		this.projects = projects;
		this.certification = certification;
		this.paperspublished = paperspublished;
		this.location = location;
	}




	public Portfolio() {
		super();
		// TODO Auto-generated constructor stub
	}




	public int getPortfolio_id() {
		return portfolio_id;
	}




	public void setPortfolio_id(int portfolio_id) {
		this.portfolio_id = portfolio_id;
	}




	public String getName() {
		return name;
	}




	public void setName(String name) {
		this.name = name;
	}




	public String getPhoto_id() {
		return photo_id;
	}




	public void setPhoto_id(String photo_id) {
		this.photo_id = photo_id;
	}




	public String getPersonaldetails() {
		return personaldetails;
	}




	public void setPersonaldetails(String personaldetails) {
		this.personaldetails = personaldetails;
	}




	public String getQualifications() {
		return qualifications;
	}




	public void setQualifications(String qualifications) {
		this.qualifications = qualifications;
	}




	public String getProjects() {
		return projects;
	}




	public void setProjects(String projects) {
		this.projects = projects;
	}




	public String getCertification() {
		return certification;
	}




	public void setCertification(String certification) {
		this.certification = certification;
	}




	public String getPaperspublished() {
		return paperspublished;
	}




	public void setpaperspublished(String paperspublished) {
		this.paperspublished = paperspublished;
	}




	public String getLocation() {
		return location;
	}




	public void setLocation(String location) {
		this.location = location;
	}




	public String getSubmitted_by() {
		return submitted_by;
	}




	public void setSubmitted_by(String submitted_by) {
		this.submitted_by = submitted_by;
	}
    
	
	
}
