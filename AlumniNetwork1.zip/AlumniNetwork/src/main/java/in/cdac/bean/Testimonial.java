package in.cdac.bean;

public class Testimonial {
	
	private int testimonial_id;
	private String testimonial_text;
	private String testimonial_type;
	private String filepath;
	private String status;
	private String submitted_by;
	
	
	
	public Testimonial() {
		super();
		// TODO Auto-generated constructor stub
	}



	public Testimonial(String testimonial_text, String testimonial_type, String filepath, String status,
			String submitted_by) {
		super();
		this.testimonial_text = testimonial_text;
		this.testimonial_type = testimonial_type;
		this.filepath = filepath;
		this.status = status;
		this.submitted_by = submitted_by;
	}



	public Testimonial(int testimonial_id, String testimonial_text, String testimonial_type, String filepath,
			String status, String submitted_by) {
		super();
		this.testimonial_id = testimonial_id;
		this.testimonial_text = testimonial_text;
		this.testimonial_type = testimonial_type;
		this.filepath = filepath;
		this.status = status;
		this.submitted_by = submitted_by;
	}



	public Testimonial(int testimonial_id, String testimonial_text, String testimonial_type, String filepath,
			String status) {
		super();
		this.testimonial_id = testimonial_id;
		this.testimonial_text = testimonial_text;
		this.testimonial_type = testimonial_type;
		this.filepath = filepath;
		this.status = status;
	}





	public Testimonial(int testimonial_id) {
		super();
		this.testimonial_id = testimonial_id;
	}



	public int getTestimonial_id() {
		return testimonial_id;
	}



	public void setTestimonial_id(int testimonial_id) {
		this.testimonial_id = testimonial_id;
	}



	public String getTestimonial_text() {
		return testimonial_text;
	}



	public void setTestimonial_text(String testimonial_text) {
		this.testimonial_text = testimonial_text;
	}



	public String getTestimonial_type() {
		return testimonial_type;
	}



	public void setTestimonial_type(String testimonial_type) {
		this.testimonial_type = testimonial_type;
	}



	public String getFilepath() {
		return filepath;
	}



	public void setFilepath(String filepath) {
		this.filepath = filepath;
	}



	public String getStatus() {
		return status;
	}



	public void setStatus(String status) {
		this.status = status;
	}



	public String getSubmitted_by() {
		return submitted_by;
	}



	public void setSubmitted_by(String submitted_by) {
		this.submitted_by = submitted_by;
	}
	
	
}
