package in.cdac.bean;

public class Placementdetails {
	private int placement_id;
	private int batchid;
	private String orgname;
	private String submitted_by;
	
	
	public Placementdetails() {
		super();
	}
	public Placementdetails(int placement_id, int batchid, String orgname, String submitted_by) {
		super();
		this.placement_id = placement_id;
		this.batchid = batchid;
		this.orgname = orgname;
		this.submitted_by = submitted_by;
	}
	public Placementdetails(int placement_id, int batchid, String orgname) {
		super();
		this.placement_id = placement_id;
		this.batchid = batchid;
		this.orgname = orgname;
	}
	public Placementdetails(int batchid, String orgname, String submitted_by) {
		super();
		this.batchid = batchid;
		this.orgname = orgname;
		this.submitted_by = submitted_by;
	}
	public int getPlacement_id() {
		return placement_id;
	}
	public void setPlacement_id(int placement_id) {
		this.placement_id = placement_id;
	}
	public int getBatchid() {
		return batchid;
	}
	public void setBatchid(int batchid) {
		this.batchid = batchid;
	}
	public String getOrgname() {
		return orgname;
	}
	public void setOrgname(String orgname) {
		this.orgname = orgname;
	}
	public String getSubmitted_by() {
		return submitted_by;
	}
	public void setSubmitted_by(String submitted_by) {
		this.submitted_by = submitted_by;
	}
	@Override
	public String toString() {
		return "Placementdetails [placement_id=" + placement_id + ", batchid=" + batchid + ", orgname=" + orgname
				+ ", submitted_by=" + submitted_by + "]";
	}

}
