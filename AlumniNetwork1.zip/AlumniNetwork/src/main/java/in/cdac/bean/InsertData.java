package in.cdac.bean;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
/**
 * Servlet implementation class InsertData
 */
@WebServlet("/InsertData")
public class InsertData extends HttpServlet {
  private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public InsertData() {
        super();
        // TODO Auto-generated constructor stub
    }
  /**
   * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
   */
  protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    // TODO Auto-generated method stub
   // response.getWriter().append("Served at: ").append(request.getContextPath());
  }
  /**
   * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
   */
  protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    // TODO Auto-generated method stub
   // doGet(request, response);
    PrintWriter out = response.getWriter();
    
    String user_rollno = request.getParameter("rollno");
    String user_name = request.getParameter("name");
    String user_email = request.getParameter("email");
    String user_mob = request.getParameter("mobile");
    String user_batch = request.getParameter("batch");
    String user_branch = request.getParameter("branch");
    String password = request.getParameter("pass");
    
    //database Connectivity code.........
    try {
      Class.forName("com.mysql.jdbc.Driver");
      Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/alumni","root","");
          Statement stmt = con.createStatement();
          stmt.executeUpdate("insert into user_reg (user_rollno,user_name,user_email,user_mob,user_batch,user_branch)values('"+user_rollno+"','"+user_name+"','"+user_email+"','"+user_mob+"','"+user_batch+"','"+user_branch+"') ");
          stmt.executeUpdate("insert into user_login_details (user_rollno,password)values('"+user_rollno+"','"+password+"') ");
          
          //out.println("Data is inserted successfully in both tables");
          RequestDispatcher dispatcher =
			       getServletContext().getRequestDispatcher("/RegistrationSuccess.jsp");
			 dispatcher.forward(request, response);
          
          
    } catch (ClassNotFoundException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    } catch (SQLException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }
   
  }
}