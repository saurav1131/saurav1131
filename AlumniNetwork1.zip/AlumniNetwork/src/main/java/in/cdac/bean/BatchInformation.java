package in.cdac.bean;

import java.sql.Date;

public class BatchInformation {
	private int batch_id;
	private String batch_name;
	private Date batch_start_date;
	private Date batch_end_date;
	private String status;
	private String submitted_by;
	
	
	
	
	
	public BatchInformation(String batch_name, Date batch_start_date, Date batch_end_date, String status,
			String submitted_by) {
		super();
		this.batch_name = batch_name;
		this.batch_start_date = batch_start_date;
		this.batch_end_date = batch_end_date;
		this.status = status;
		this.submitted_by = submitted_by;
	}





	public BatchInformation(int batch_id) {
		super();
		this.batch_id = batch_id;
		//this.batch_start_date = batch_start_date;
	}





	public BatchInformation(int batch_id, String batch_name, Date batch_start_date, Date batch_end_date,
			String status, String submitted_by) {
		super();
		this.batch_id = batch_id;
		this.batch_name = batch_name;
		this.batch_start_date = batch_start_date;
		this.batch_end_date = batch_end_date;
		this.status = status;
		this.submitted_by = submitted_by;
	}





	public BatchInformation() {
		super();
		// TODO Auto-generated constructor stub
	}





	public int getBatch_id() {
		return batch_id;
	}





	public void setBatch_id(int batch_id) {
		this.batch_id = batch_id;
	}





	public String getBatch_name() {
		return batch_name;
	}





	public void setBatch_name(String batch_name) {
		this.batch_name = batch_name;
	}





	public Date getBatch_start_date() {
		return batch_start_date;
	}





	public void setBatch_start_date(Date batch_start_date) {
		this.batch_start_date = batch_start_date;
	}





	public Date getBatch_end_date() {
		return batch_end_date;
	}





	public void setBatch_end_date(Date batch_end_date) {
		this.batch_end_date = batch_end_date;
	}





	public String getStatus() {
		return status;
	}





	public void setStatus(String status) {
		this.status = status;
	}





	public String getSubmitted_by() {
		return submitted_by;
	}





	public void setSubmitted_by(String submitted_by) {
		this.submitted_by = submitted_by;
	}
	
	
	
	
	
	
	
	
	
	
}

