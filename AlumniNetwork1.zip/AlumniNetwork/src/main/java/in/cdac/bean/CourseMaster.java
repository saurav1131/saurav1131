package in.cdac.bean;



public class CourseMaster {
	
	private int course_id;
	private String course_name;
	private String course_detail;
	private String course_batch;
	private String submitted_by;
	
	
	
	public CourseMaster() {
		super();
		// TODO Auto-generated constructor stub
	}




	public CourseMaster(int course_id, String course_name, String course_detail, String course_batch,
			String submitted_by) {
		super();
		this.course_id = course_id;
		this.course_name = course_name;
		this.course_detail = course_detail;
		this.course_batch = course_batch;
		this.submitted_by = submitted_by;
	}




	public CourseMaster(String course_name, String course_detail, String course_batch, String submitted_by) {
		super();
		this.course_name = course_name;
		this.course_detail = course_detail;
		this.course_batch = course_batch;
		this.submitted_by = submitted_by;
	}
	
	




	public CourseMaster(int course_id, String course_name, String course_detail, String course_batch) {
		super();
		this.course_id = course_id;
		this.course_name = course_name;
		this.course_detail = course_detail;
		this.course_batch = course_batch;
	}




	public CourseMaster(int course_id) {
		super();
		
	}
	public int getCourse_id() {
		return course_id;
	}



	public void setCourse_id(int course_id) {
		this.course_id = course_id;
	}



	public String getCourse_name() {
		return course_name;
	}



	public void setCourse_name(String course_name) {
		this.course_name = course_name;
	}



	public String getCourse_detail() {
		return course_detail;
	}



	public void setCourse_detail(String course_detail) {
		this.course_detail = course_detail;
	}



	public String getCourse_batch() {
		return course_batch;
	}



	public void setCourse_batch(String course_batch) {
		this.course_batch = course_batch;
	}



	public String getSubmitted_by() {
		return submitted_by;
	}



	public void setSubmitted_by(String submitted_by) {
		this.submitted_by = submitted_by;
	}




	}



	

