package in.cdac.bean;

import java.sql.Date;

public class JobCalender {
	private int job_id;
	private String job_opening;
	private String profile;
	private int no_of_openings;
	private Date date;
	private String submitted_by;
	
	
	
	public JobCalender(int job_id, String job_opening, String profile, int no_of_openings, Date date) {
		super();
		this.job_id = job_id;
		this.job_opening = job_opening;
		this.profile = profile;
		this.no_of_openings = no_of_openings;
		this.date = date;
	}



	public JobCalender() {
		super();
		// TODO Auto-generated constructor stub
	}



	public JobCalender(String job_opening, String profile, int no_of_openings, Date date, String submitted_by) {
		super();
		this.job_opening = job_opening;
		this.profile = profile;
		this.no_of_openings = no_of_openings;
		this.date = date;
		this.submitted_by = submitted_by;
	}



	public JobCalender(int job_id, String job_opening, String profile, int no_of_openings, Date date,
			String submitted_by) {
		super();
		this.job_id = job_id;
		this.job_opening = job_opening;
		this.profile = profile;
		this.no_of_openings = no_of_openings;
		this.date = date;
		this.submitted_by = submitted_by;
	}



	public int getJob_id() {
		return job_id;
	}



	public void setJob_id(int job_id) {
		this.job_id = job_id;
	}



	public String getJob_opening() {
		return job_opening;
	}



	public void setJob_opening(String job_opening) {
		this.job_opening = job_opening;
	}



	public String getProfile() {
		return profile;
	}



	public void setProfile(String profile) {
		this.profile = profile;
	}



	public int getNo_of_openings() {
		return no_of_openings;
	}



	public void setNo_of_openings(int no_of_openings) {
		this.no_of_openings = no_of_openings;
	}



	public Date getDate() {
		return date;
	}



	public void setDate(Date date) {
		this.date = date;
	}



	public String getSubmitted_by() {
		return submitted_by;
	}



	public void setSubmitted_by(String submitted_by) {
		this.submitted_by = submitted_by;
	}
	
	
	
}
