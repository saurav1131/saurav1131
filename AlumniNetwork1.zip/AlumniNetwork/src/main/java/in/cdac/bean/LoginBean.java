package in.cdac.bean;

import java.io.Serializable;

public class LoginBean implements Serializable {
    /**
     * 
     */
    private static final long serialVersionUID = 1 ;
    private String user_rollno;
    private String password;

    public String getRollno() {
        return user_rollno;
    }

    public void setRollno(String user_rollno) {
        this.user_rollno = user_rollno;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}