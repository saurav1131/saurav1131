package in.cdac.bean;


public class JobOpening {
	
	private int job_id;
	private String job_name;
	private String job_description;
	private String job_eligibility;
	private String submitted_by;
	
	public JobOpening() {
		
	}
	
	public JobOpening(String job_name, String job_description, String job_eligibility, String submitted_by) {
		super();
		this.job_name = job_name;
		this.job_description = job_description;
		this.job_eligibility = job_eligibility;
		this.submitted_by = submitted_by;
	}

	
	public JobOpening(int job_id, String job_name, String job_description, String job_eligibility) {
		super();
		this.job_id = job_id;
		this.job_name = job_name;
		this.job_description = job_description;
		this.job_eligibility = job_eligibility;
	}

	public JobOpening(int job_id, String job_name, String job_description, String job_eligibility,
			String submitted_by) {
		super();
		this.job_id = job_id;
		this.job_name = job_name;
		this.job_description = job_description;
		this.job_eligibility = job_eligibility;
		this.submitted_by = submitted_by;
	}


	public int getJob_id() {
		return job_id;
	}


	public void setJob_id(int job_id) {
		this.job_id = job_id;
	}


	public String getJob_name() {
		return job_name;
	}


	public void setJob_name(String job_name) {
		this.job_name = job_name;
	}


	public String getJob_description() {
		return job_description;
	}


	public void setJob_description(String job_description) {
		this.job_description = job_description;
	}


	public String getJob_eligibility() {
		return job_eligibility;
	}


	public void setJob_eligibility(String job_eligibility) {
		this.job_eligibility = job_eligibility;
	}


	public String getSubmitted_by() {
		return submitted_by;
	}


	public void setSubmitted_by(String submitted_by) {
		this.submitted_by = submitted_by;
	}

//	@Override
//	public String toString() {
//		return "JobOpening [job_id=" + job_id + ", job_name=" + job_name + ", job_description=" + job_description
//				+ ", job_eligibility=" + job_eligibility + ", submitted_by=" + submitted_by + "]";
//	}
	
	
	
	
}

