package in.cdac.dao;

import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import in.cdac.bean.JobCalender;

	public class JobCalenderDAO {
		
		private String dburl="jdbc:mysql://localhost:3306/alumni";
		private String dbuname="root";
		private String dbpassword="";
		private String dbdriver="com.mysql.jdbc.Driver";
		
		public void loadDriver(String dbDriver) {
			try {
				Class.forName(dbDriver);
			} catch (ClassNotFoundException e) {
			
				e.printStackTrace();
			}
		}
		
		public Connection getConnection() {
			
			Connection con=null;
			try {
				con=DriverManager.getConnection(dburl,dbuname,dbpassword);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return con;
			
		}
		
		// For insert a record in database
		public String insert(JobCalender job_calender) {
			
			loadDriver(dbdriver);
			Connection con=getConnection();
			String result="/JobCalenderSuccess.jsp";
			
			String sql="insert into job_calender(job_opening,profile,no_of_openings,date,submitted_by) values(?,?,?,?,?)";
			
			
			try {
				PreparedStatement ps= con.prepareStatement(sql);
				
				ps.setString(1, job_calender.getJob_opening());
				ps.setString(2,job_calender.getProfile());
				ps.setInt(3,job_calender.getNo_of_openings());
				ps.setDate(4,job_calender.getDate());
				ps.setString(5, job_calender.getSubmitted_by());
				ps.executeUpdate();
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return "/err.jsp";
			}
			return result;
		}
		
		
		// For delete a record from database
		
	public String delete(JobCalender job_calender) {
			
			loadDriver(dbdriver);
			Connection con=getConnection();
			String result="/JobCalenderHome.jsp";
			
			String sql1="delete from job_calender where job_id=?";
			
			try {
				PreparedStatement ps= con.prepareStatement(sql1);
				
				ps.setInt(1,job_calender.getJob_id());
				ps.executeUpdate();
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return "Record not deleted..";
			}
			return result;
		}


	    // For update a record...

	    
	public String update(JobCalender job_calender) {
		
		loadDriver(dbdriver);
		Connection con=getConnection();
		String result="/JobCalenderUpdateSuccess.jsp";
		
		String sql="update job_calender set job_opening=?, profile=?,no_of_openings=?,date=? where job_id=?";
		
		try {
			PreparedStatement ps= con.prepareStatement(sql);
			
			
			ps.setString(1, job_calender.getJob_opening());
			ps.setString(2, job_calender.getProfile());
			ps.setInt(3,job_calender.getNo_of_openings());
			ps.setDate(4,job_calender.getDate());
			//ps.setString(5,job_calender.getSubmitted_by());
			ps.setInt(5, job_calender.getJob_id());
			
			
			//ps.setString(5, user.getSubmitted_by());
			ps.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "Record not updated";
		}
		return result;
	}

	}