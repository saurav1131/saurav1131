package in.cdac.dao;


import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.PreparedStatement;

import java.sql.SQLException;

import in.cdac.bean.Placementdetails;



public class PlacementdetailsDAO {
	
	private String dburl="jdbc:mysql://localhost:3306/alumni";
	private String dbuname="root";
	private String dbpassword="";
	private String dbdriver="com.mysql.jdbc.Driver";
	
	public void loadDriver(String dbDriver) {
		try {
			Class.forName(dbDriver);
		} catch (ClassNotFoundException e) {
		
			e.printStackTrace();
		}
	}
	
	public Connection getConnection() {
		
		Connection con=null;
		try {
			con=DriverManager.getConnection(dburl,dbuname,dbpassword);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;
		
	}
	
	// For insert a record in database
	public String insert(Placementdetails placementdetails) {
		
		loadDriver(dbdriver);
		Connection con=getConnection();
		String result="/PlacementdetailsSuccessInsert.jsp";
		
		String sql="insert into placementdetails(batchid,orgname,submitted_by) values(?,?,?)";
		
		try {
			PreparedStatement ps= con.prepareStatement(sql);
			
			ps.setInt(1,placementdetails.getBatchid());
			ps.setString(2, placementdetails.getOrgname());
			ps.setString(3,placementdetails.getSubmitted_by());
			
			ps.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "/PlacementdetailsInsertError.jsp";
		}
		return result;
	}

	
	
	// For delete a record from database
	
public String delete(Placementdetails placementdetails) {
	
		loadDriver(dbdriver);
	Connection con=getConnection();
	String result="/PlacementdetailsHome.jsp";
	
		String sql1="delete from placementdetails where placement_id=?";
	
	try {
		PreparedStatement ps= con.prepareStatement(sql1);
		
			ps.setInt(1,placementdetails.getPlacement_id());
			ps.executeUpdate();
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return "/PlacementdetailsDeleteError.jsp";
		}
		return result;
 }


    // For update a record...

    
public String update(Placementdetails placementdetails) {
	
	loadDriver(dbdriver);
	Connection con=getConnection();
	String result="/PlacementdetailsSuccessUpdate.jsp";
	
	String sql="update placementdetails set batchid=?,orgname=? where placement_id=?";
	
	try {
		PreparedStatement ps= con.prepareStatement(sql);
		
		
		
		ps.setInt(1, placementdetails.getBatchid() );
		ps.setString(2,placementdetails.getOrgname());
		//ps.setString(3,placementdetails.getSubmitted_by());
		ps.setInt(3,placementdetails.getPlacement_id());
		
		
		ps.executeUpdate();
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return "Record not updated";
	}
	return result;
}

}