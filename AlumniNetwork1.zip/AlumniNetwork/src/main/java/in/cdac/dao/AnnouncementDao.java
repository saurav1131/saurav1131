package in.cdac.dao;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

import in.cdac.bean.AnnouncementUser;


public class AnnouncementDao {
	
	private String dburl="jdbc:mysql://localhost:3306/alumni";
	private String dbuname="root";
	private String dbpassword="";
	private String dbdriver="com.mysql.jdbc.Driver";
	
	public void loadDriver(String dbDriver) {
		try {
			Class.forName(dbDriver);
		} catch (ClassNotFoundException e) {
		
			e.printStackTrace();
		}
	}
	
	public Connection getConnection() {
		
		Connection con=null;
		try {
			con=DriverManager.getConnection(dburl,dbuname,dbpassword);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;
		
	}
	
	// For insert a record in database
	public String insert(AnnouncementUser user) {
		
		loadDriver(dbdriver);
		Connection con=getConnection();
		String result="/AnnouncementInsertSuccess.jsp";
		
		String sql="insert into announcements(announcement_title,announcement_msg,announcement_start_date,announcement_end_date,submitted_by) values(?,?,?,?,?)";
		
		try {
			PreparedStatement ps= con.prepareStatement(sql);
			
			ps.setString(1, user.getAnnouncement_title());
			ps.setString(2, user.getAnnouncement_msg());
			ps.setDate(3,user.getAnnouncement_start_date());
			ps.setDate(4,user.getAnnouncement_end_date());
			ps.setString(5, user.getSubmitted_by());
			ps.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "/AnnouncementInsertError.jsp";
		}
		return result;
	}
	
	
	// For delete a record from database
	
public String delete(AnnouncementUser user) {
		
		loadDriver(dbdriver);
		Connection con=getConnection();
	
		String result="/AnnouncementHome.jsp";
		String sql1="delete from announcements where announcement_id=?";
		
		try {
			PreparedStatement ps= con.prepareStatement(sql1);
			
			ps.setInt(1, user.getAnnouncement_id());
			ps.executeUpdate();
			
		} 
		catch (SQLException e) {
			
			e.printStackTrace();
			return "/AnnouncementDeleteError.jsp";
		}
	
		return result;
	}


    // For update a record...

    
public String update(AnnouncementUser user) {
	
	loadDriver(dbdriver);
	Connection con=getConnection();
	String result="/AnnouncementUpdateSuccess.jsp";
	
	String sql="update announcements set announcement_title=?,announcement_msg=?,announcement_start_date=?,announcement_end_date=? where announcement_id=?";
	
	try {
		PreparedStatement ps= con.prepareStatement(sql);
		
		
		ps.setString(1, user.getAnnouncement_title());
		ps.setString(2, user.getAnnouncement_msg());
		ps.setDate(3,user.getAnnouncement_start_date());
		ps.setDate(4,user.getAnnouncement_end_date());
		ps.setInt(5, user.getAnnouncement_id());
		
		//ps.setString(5, user.getSubmitted_by());
		ps.executeUpdate();
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return "Record not updated";
	}
	
	return result;
}

}


