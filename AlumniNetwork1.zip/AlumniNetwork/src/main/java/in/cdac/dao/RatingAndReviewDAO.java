package in.cdac.dao;





import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.PreparedStatement;

import java.sql.SQLException;

import in.cdac.bean.*;



public class RatingAndReviewDAO {
	
	private String dburl="jdbc:mysql://localhost:3306/alumni";
	private String dbuname="root";
	private String dbpassword="";
	private String dbdriver="com.mysql.jdbc.Driver";
	
	public void loadDriver(String dbDriver) {
		try {
			Class.forName(dbDriver);
		} catch (ClassNotFoundException e) {
		
			e.printStackTrace();
		}
	}
	
	public Connection getConnection() {
		
		Connection con=null;
		try {
			con=DriverManager.getConnection(dburl,dbuname,dbpassword);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;
		
	}
	
	// For insert a record in database
	public String insert(in.cdac.bean.RatingAndReview ratingandreview) {
		
		loadDriver(dbdriver);
		Connection con=getConnection();
		String result="/RatingReviewInsertSuccess.jsp";
		
		String sql="insert into ratingandreview(review_text,overall_rating,submitted_by) values(?,?,?)";
		
		try {
			PreparedStatement ps= con.prepareStatement(sql);
			
			ps.setString(1,ratingandreview.getReview_text());
			ps.setInt(2,ratingandreview.getOverall_rating());	
			ps.setString(3,ratingandreview.getSubmitted_by());
			
			ps.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "/RatingReviewInsertError.jsp";
		}
		return result;
	}

	
	
	// For delete a record from database
	
public String delete(RatingAndReview ratingandreview) {
	
		loadDriver(dbdriver);
	Connection con=getConnection();
	String result="/RatingAndReviewDeleteSuccess.jsp";
	
		String sql1="delete from ratingandreview where review_id=?";
	
	try {
		PreparedStatement ps= con.prepareStatement(sql1);
		
			ps.setInt(1,ratingandreview.getReview_id());
			ps.executeUpdate();
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return "/RatingReviewDeleteError.jsp";
		}
		return result;
 }


    // For update a record...

    
public String update(RatingAndReview ratingandreview) {
	
	loadDriver(dbdriver);
	Connection con=getConnection();
	String result="/RatingReviewUpdateSuccess.jsp";
	
	String sql="update ratingandreview set review_text=?,overall_rating=? where review_id=?";
	
	try {
		PreparedStatement ps= con.prepareStatement(sql);
		
		
		//ps.setInt(1, ratingandreview.getReview_id());
		ps.setString(1,ratingandreview.getReview_text());
		ps.setInt(2,ratingandreview.getOverall_rating());	
		
		//ps.setString(4,job_opening.getSubmitted_by());
		ps.setInt(3, ratingandreview.getReview_id());
		
		//ps.setString(5, user.getSubmitted_by());
		ps.executeUpdate();
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return "RatingReviewUpdateError.jsp";
	}
	return result;
}

}