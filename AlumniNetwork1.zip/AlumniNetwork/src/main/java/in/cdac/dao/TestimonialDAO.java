package in.cdac.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import in.cdac.bean.Testimonial;

public class TestimonialDAO {
	
	private String dburl="jdbc:mysql://localhost:3306/alumni";
	private String dbuname="root";
	private String dbpassword="";
	private String dbdriver="com.mysql.jdbc.Driver";
	
	public void loadDriver(String dbDriver) {
		try {
			Class.forName(dbDriver);
		} catch (ClassNotFoundException e) {
		
			e.printStackTrace();
		}
	}
	
	public Connection getConnection() {
		
		Connection con=null;
		try {
			con=DriverManager.getConnection(dburl,dbuname,dbpassword);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;
		
	}
	
public String insert(Testimonial testimonial) {
		
		loadDriver(dbdriver);
		Connection con=getConnection();
		String result="/TestimonialInsertSuccess.jsp";
		
		String sql="insert into testimonial(testimonial_text,testimonial_type,filepath,status,submitted_by) values(?,?,?,?,?)";
		
		try {
			PreparedStatement ps= con.prepareStatement(sql);
			
			ps.setString(1,testimonial.getTestimonial_text());
			ps.setString(2,testimonial.getTestimonial_type());
			ps.setString(3,testimonial.getFilepath());
			ps.setString(4,testimonial.getStatus());
			ps.setString(5,testimonial.getSubmitted_by());
			
			ps.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "/Testimonialerr.jsp";
		}
		return result;
	}

//For delete a record from database

public String delete(Testimonial testimonial) {
	
		loadDriver(dbdriver);
	Connection con=getConnection();
	String result="/TestimonialHome.jsp";
	
		String sql1="delete from testimonial where testimonial_id=?";
	
	try {
		PreparedStatement ps= con.prepareStatement(sql1);
		
			ps.setInt(1,testimonial.getTestimonial_id());
			ps.executeUpdate();
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return "Record not deleted..";
		}
		return result;
}

public String update(Testimonial testimonial) {
	
	loadDriver(dbdriver);
	Connection con=getConnection();
	String result="/TestimonialUpdateSuccess.jsp";
	
	String sql="update testimonial set testimonial_text=?,testimonial_type=?,filepath=?,status=? where testimonial_id=?";
	
	try {
		PreparedStatement ps= con.prepareStatement(sql);
		
		
		ps.setString(1, testimonial.getTestimonial_text());
		ps.setString(2, testimonial.getTestimonial_type());
		ps.setString(3,testimonial.getFilepath());
		ps.setString(4,testimonial.getStatus());
		ps.setInt(5,testimonial.getTestimonial_id());
		
		//ps.setString(5, user.getSubmitted_by());
		ps.executeUpdate();
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return "Record not updated";
	}
	return result;
}

}
