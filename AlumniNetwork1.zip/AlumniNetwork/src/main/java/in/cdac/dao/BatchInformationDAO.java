package in.cdac.dao;



import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import in.cdac.bean.BatchInformation;

public class  BatchInformationDAO {
	
	private String dburl="jdbc:mysql://localhost:3306/alumni";
	private String dbuname="root";
	private String dbpassword="";
	private String dbdriver="com.mysql.jdbc.Driver";
	
	public void loadDriver(String dbDriver) {
		try {
			Class.forName(dbDriver);
		} catch (ClassNotFoundException e) {
		
			e.printStackTrace();
		}
	}
	
	public Connection getConnection() {
		
		Connection con=null;
		try {
			con=DriverManager.getConnection(dburl,dbuname,dbpassword);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;
		
	}
	
public String insert( BatchInformation   batch_information ) {
		
		loadDriver(dbdriver);
		Connection con=getConnection();
		String result="/BatchInformationSuccess.jsp";
		
		String sql="insert into  batch_information (batch_name,batch_start_date,batch_end_date,status,submitted_by) values(?,?,?,?,?)";
		
		try {
			PreparedStatement ps= con.prepareStatement(sql);
			
			ps.setString(1,batch_information.getBatch_name());
			ps.setDate(2,batch_information.getBatch_start_date());
			ps.setDate(3,batch_information.getBatch_end_date());
			ps.setString(4,batch_information.getStatus());
			ps.setString(5,batch_information.getSubmitted_by());
			
			ps.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "/BatchInformationerr.jsp";
		}
		return result;
	}

//For delete a record from database

public String delete(BatchInformation  batch_information ) {
	
		loadDriver(dbdriver);
	Connection con=getConnection();
	String result="/BatchInformationHome.jsp";
	
		String sql1="delete from batch_information  where batch_id=?";
	
	try {
		PreparedStatement ps= con.prepareStatement(sql1);
		
			ps.setInt(1,batch_information .getBatch_id());
			ps.executeUpdate();
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return "Record not deleted..";
		}
		return result;
}

public String update(BatchInformation  batch_information ) {
	
	loadDriver(dbdriver);
	Connection con=getConnection();
	String result="/BatchInformationSuccessUpdate.jsp";
	
	String sql="update batch_information set  batch_name = ?, batch_start_date = ?, batch_end_date = ?, status = ? where batch_id=?";
	
	try {
		PreparedStatement ps= con.prepareStatement(sql);
		
		
		ps.setString(1, batch_information.getBatch_name());
		ps.setDate(2, batch_information.getBatch_start_date());
		ps.setDate(3,batch_information.getBatch_end_date());
		ps.setString(4,batch_information.getStatus());
		ps.setInt(5,batch_information.getBatch_id());
		
		//ps.setString(5, user.getSubmitted_by());
		ps.executeUpdate();
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return "Record not updated";
	}
	return result;
}

}