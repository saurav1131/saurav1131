
package in.cdac.dao;

import in.cdac.bean.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;


public class PortfolioDao {
	
	private String dburl="jdbc:mysql://localhost:3306/alumni";
	private String dbuname="root";
	private String dbpassword="";
	private String dbdriver="com.mysql.jdbc.Driver";
	
	public void loadDriver(String dbDriver) {
		try {
			Class.forName(dbDriver);
		} catch (ClassNotFoundException e) {
		
			e.printStackTrace();
		}
	}
	
	public Connection getConnection() {
		
		Connection con=null;
		try {
			con=DriverManager.getConnection(dburl,dbuname,dbpassword);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;
		
	}
	
	// For insert a record in database
	public String insert(Portfolio portfolio) {
		
		loadDriver(dbdriver);
		Connection con=getConnection();
		String result="/PortfolioInsertSuccess.jsp";
		
		String sql="insert into portfolio(name,photo_id,personaldetails,qualification,projects,certification,paperspublished,location,submitted_by) values(?,?,?,?,?,?,?,?,?)";
		
		try {
			PreparedStatement ps= con.prepareStatement(sql);
			
			//ps.setInt(1, portfolio.getPortfolio_id());
			ps.setString(1, portfolio.getName());
			ps.setString(2,portfolio.getPhoto_id());
			ps.setString(3,portfolio.getPersonaldetails());
			ps.setString(4, portfolio.getQualifications());
			ps.setString(5, portfolio.getProjects());
			ps.setString(6, portfolio.getCertification());
			ps.setString(7, portfolio.getPaperspublished());
			ps.setString(8, portfolio.getLocation());
			ps.setString(9, portfolio.getSubmitted_by());
	
			ps.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "/Portfolioerr.jsp";
		}
		return result;
	}
	
	
	// For delete a record from database
	
public String delete(Portfolio portfolio) {
		
		loadDriver(dbdriver);
		Connection con=getConnection();
		String result="/PortfolioHome.jsp";
		
		String sql1="delete from portfolio where portfolio_id=?";
		
		try {
			PreparedStatement ps= con.prepareStatement(sql1);
			
			ps.setInt(1, portfolio.getPortfolio_id());
			ps.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "Record not deleted..";
		}
		return result;
	}


    // For update a record...

    
public String update(Portfolio portfolio) {
	
	loadDriver(dbdriver);
	Connection con=getConnection();
	String result="/PortfolioUpdateSuccess.jsp";
	
	String sql="update portfolio set name=?,photo_id=?,personaldetails=?,qualification=?,projects=?,certification=?,paperspublished=?,location=? where portfolio_id=?";
	
	try {
		PreparedStatement ps= con.prepareStatement(sql);
		
		
	
		ps.setString(1, portfolio.getName());
		ps.setString(2,portfolio.getPhoto_id());
		ps.setString(3,portfolio.getPersonaldetails());
		ps.setString(4, portfolio.getQualifications());
		ps.setString(5, portfolio.getProjects());
		ps.setString(6, portfolio.getCertification());
		ps.setString(7, portfolio.getPaperspublished());
		ps.setString(8, portfolio.getLocation());
		ps.setInt(9, portfolio.getPortfolio_id());
		//ps.setString(10, portfolio.getsubmitted_by());

		ps.executeUpdate();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return "Record not updated";
	}
	return result;
}

}