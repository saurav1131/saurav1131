package in.cdac.dao;

import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.PreparedStatement;

import java.sql.SQLException;

import in.cdac.bean.JobOpening;





public class JobopeningDAO {
	
	private String dburl="jdbc:mysql://localhost:3306/alumni";
	private String dbuname="root";
	private String dbpassword="";
	private String dbdriver="com.mysql.jdbc.Driver";
	
	public void loadDriver(String dbDriver) {
		try {
			Class.forName(dbDriver);
		} catch (ClassNotFoundException e) {
		
			e.printStackTrace();
		}
	}
	
	public Connection getConnection() {
		
		Connection con=null;
		try {
			con=DriverManager.getConnection(dburl,dbuname,dbpassword);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;
		
	}
	
	// For insert a record in database
	public String insert(JobOpening job_opening) {
		
		loadDriver(dbdriver);
		Connection con=getConnection();
		String result="/JobInsertSuccess.jsp";
		
		String sql="insert into job_opening(job_name,job_description,job_eligibility,submitted_by) values(?,?,?,?)";
		
		try {
			PreparedStatement ps= con.prepareStatement(sql);
			
			ps.setString(1,job_opening.getJob_name());
			ps.setString(2,job_opening.getJob_description());
			ps.setString(3, job_opening.getJob_eligibility());
			ps.setString(4,job_opening.getSubmitted_by());
			
			ps.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "/JobOpeningError.jsp";
		}
		return result;
	}

	
	
	// For delete a record from database
	
public String delete(JobOpening job_opening) {
	
		loadDriver(dbdriver);
	Connection con=getConnection();
	String result="/JobOpeningHome.jsp";
	
		String sql1="delete from job_opening where job_id=?";
	
	try {
		PreparedStatement ps= con.prepareStatement(sql1);
		
			ps.setInt(1,job_opening.getJob_id());
			ps.executeUpdate();
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return "/JobOpeningDeleteError.jsp";
		}
		return result;
 }


    // For update a record...

    
public String update(JobOpening job_opening) {
	
	loadDriver(dbdriver);
	Connection con=getConnection();
	String result="/JobUpdateSuccess.jsp";
	
	String sql="update job_opening set job_name=?,job_description=?,job_eligibility=? where job_id=?";
	
	try {
		PreparedStatement ps= con.prepareStatement(sql);
		
		
		ps.setString(1, job_opening.getJob_name());
		ps.setString(2, job_opening.getJob_description());
		ps.setString(3,job_opening.getJob_eligibility());
		
		ps.setInt(4, job_opening.getJob_id());
		
		
		ps.executeUpdate();
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return "/JobOpeningUpdateError.jsp";
	}
	return result;
}

}