package in.cdac.dao;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import in.cdac.bean.CourseMaster;

public class CourseMasterDAO {
	
	private String dburl="jdbc:mysql://localhost:3306/alumni";
	private String dbuname="root";
	private String dbpassword="";
	private String dbdriver="com.mysql.jdbc.Driver";
	
	public void loadDriver(String dbDriver) {
		try {
			Class.forName(dbDriver);
		} catch (ClassNotFoundException e) {
		
			e.printStackTrace();
		}
	}
	
	public Connection getConnection() {
		
		Connection con=null;
		try {
			con=DriverManager.getConnection(dburl,dbuname,dbpassword);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;
		
	}
	
public String insert(CourseMaster course_master) {
		
		loadDriver(dbdriver);
		Connection con=getConnection();
		String result="/CourseMasterInsertSuccess.jsp";
		
		String sql="insert into course_master(course_name,course_detail,course_batch,submitted_by) values(?,?,?,?)";
		
		try {
			PreparedStatement ps= con.prepareStatement(sql);
			
			ps.setString(1,course_master.getCourse_name());
			ps.setString(2,course_master.getCourse_detail());
			ps.setString(3,course_master.getCourse_batch());
			ps.setString(4,course_master.getSubmitted_by());
			
			ps.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "/CourseMasterInsertError.jsp";
		}
		return result;
	}

//For delete a record from database

public String delete(CourseMaster course_master) {
	
		loadDriver(dbdriver);
	Connection con=getConnection();
	String result="/CourseMasterHome.jsp";
	
		String sql1="delete from course_master where course_id=?";
	
	try {
		PreparedStatement ps= con.prepareStatement(sql1);
		
			ps.setInt(1,course_master.getCourse_id());
			ps.executeUpdate();
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return "Record not deleted..";
		}
		return result;
}

public String update(CourseMaster course_master) {
	
	loadDriver(dbdriver);
	Connection con=getConnection();
	String result="/CourseMasterSuccessUpdate.jsp";
	
	String sql="update course_master set course_name=?,course_detail=?,course_batch=? where course_id=?";
	
	try {
		PreparedStatement ps= con.prepareStatement(sql);
		
	
		ps.setString(1, course_master.getCourse_name());
		ps.setString(2, course_master.getCourse_detail());
		ps.setString(3,course_master.getCourse_batch());
		ps.setInt(4,course_master.getCourse_id());

		
		//ps.setString(5, user.getSubmitted_by());
		ps.executeUpdate();
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return "Record not updated";
	}
	return result;
}

}
