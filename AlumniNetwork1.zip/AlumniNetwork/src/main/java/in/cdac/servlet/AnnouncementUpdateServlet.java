package in.cdac.servlet;


import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import in.cdac.bean.AnnouncementUser;
import in.cdac.dao.AnnouncementDao;


@WebServlet("/AnnouncementUpdateServlet")
public class AnnouncementUpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public AnnouncementUpdateServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int announcement_id =Integer.parseInt(request.getParameter("uid"));
		String announcement_title=request.getParameter("utitle");
		String announcement_msg=request.getParameter("umsg");
		
		
	  String start_date=request.getParameter("ustart_date");
	  SimpleDateFormat sdf=new SimpleDateFormat("yyyy-mm-dd");
	  java.util.Date udob = null;
	try {
		udob = sdf.parse(start_date);
	} catch (ParseException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	  long ms=udob.getTime();
	  java.sql.Date announcement_start_date=new java.sql.Date(ms);

		
		
		
	  String end_date=request.getParameter("uend_date");

	  java.util.Date udob1 = null;
	try {
		udob1 = sdf.parse(end_date);
	} catch (ParseException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	  long ms1=udob1.getTime();
	  java.sql.Date announcement_end_date=new java.sql.Date(ms1);
	
	
		
	  AnnouncementUser user =new AnnouncementUser(announcement_id,announcement_title,announcement_msg,announcement_start_date,announcement_end_date);
		
		AnnouncementDao aDao=new AnnouncementDao();
		String result=aDao.update(user);
	    //response.getWriter().print(result);
		
		if(result == "/AnnouncementUpdateSuccess.jsp") {
			RequestDispatcher dispatcher =
				       getServletContext().getRequestDispatcher(result);
				 dispatcher.forward(request, response);
				 }
//			else {
//				RequestDispatcher dispatcher =
//					       getServletContext().getRequestDispatcher(result);
//					 dispatcher.forward(request, response);
//				
//			}
//	
	}
	
	}


