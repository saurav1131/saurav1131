package in.cdac.servlet;
import in.cdac.bean.JobOpening;
import in.cdac.dao.JobopeningDAO;
import java.io.IOException;


import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



/**
 * Servlet implementation class UpdateServlet
 */
@WebServlet("/JobOpeningUpdateServlet")
public class JobOpeningUpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public JobOpeningUpdateServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int job_id =Integer.parseInt(request.getParameter("uid"));
		String job_name=request.getParameter("utitle");
		String job_description=request.getParameter("umsg");
		String job_eligibility=request.getParameter("uelgibility");
		
	
	  //String submitted_by=request.getParameter("usubmitted");
		
		JobOpening user =new JobOpening(job_id,job_name,job_description,job_eligibility);
		
		JobopeningDAO jDao=new JobopeningDAO();
		String result=jDao.update(user);
	    //response.getWriter().print(result);
		
		if(result == "/JobUpdateSuccess.jsp") {
			RequestDispatcher dispatcher =
				       getServletContext().getRequestDispatcher(result);
				 dispatcher.forward(request, response);
				 }
			else {
				RequestDispatcher dispatcher =
					       getServletContext().getRequestDispatcher("/JobOpeningUpdateError.jsp");
					 dispatcher.forward(request, response);
				
			}
	
	}
	
	}