package in.cdac.servlet;


import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import in.cdac.bean.AnnouncementUser;
import in.cdac.dao.AnnouncementDao;


@WebServlet("/AnnnouncementDeleteServlet")
public class AnnouncementDeleteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
    public AnnouncementDeleteServlet() {
        super();
      
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int announcement_id =Integer.parseInt(request.getParameter("idd"));
		AnnouncementUser user =new AnnouncementUser(announcement_id,null,null,null,null);
		AnnouncementDao dao=new AnnouncementDao();
		String result=dao.delete(user);
		//response.getWriter().print(result);
		if(result == "/AnnouncementHome.jsp") {
			RequestDispatcher dispatcher =
				       getServletContext().getRequestDispatcher(result);
				 dispatcher.forward(request, response);
				 }
		else{
				RequestDispatcher dispatcher =
					       getServletContext().getRequestDispatcher("/AnnouncementDeleteError.jsp");
					 dispatcher.forward(request, response);
				
			}
	
		
	}

}
