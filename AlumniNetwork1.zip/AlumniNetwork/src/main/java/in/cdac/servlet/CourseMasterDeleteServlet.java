package in.cdac.servlet;


import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import in.cdac.bean.CourseMaster;
import in.cdac.dao.CourseMasterDAO;


@WebServlet("/CourseMasterDeleteServlet")
public class CourseMasterDeleteServlet  extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
    public CourseMasterDeleteServlet() {
        super();
      
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int course_id =Integer.parseInt(request.getParameter("id"));
		CourseMaster user =new CourseMaster(course_id,null,null,null,null);
		CourseMasterDAO dao=new CourseMasterDAO();
		String result=dao.delete(user);
		//response.getWriter().print(result);
		if(result == "/CourseMasterHome.jsp") {
			RequestDispatcher dispatcher =
				       getServletContext().getRequestDispatcher(result);
				 dispatcher.forward(request, response);
				 }
//		else{
//				RequestDispatcher dispatcher =
//					       getServletContext().getRequestDispatcher("/CourseMasterHome.jsp");
//					 dispatcher.forward(request, response);
//				
//			}
//	
		
	}

}