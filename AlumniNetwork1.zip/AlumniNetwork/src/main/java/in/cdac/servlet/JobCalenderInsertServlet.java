package in.cdac.servlet;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import in.cdac.bean.JobCalender;
import in.cdac.dao.JobCalenderDAO;


@WebServlet("/JobCalenderInsertServlet")
public class JobCalenderInsertServlet extends HttpServlet
{
	private static final long serialVersionUID = 1L;
	/**
     * @see HttpServlet#HttpServlet()
     */
    public JobCalenderInsertServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//int job_id =Integer.parseInt(request.getParameter("id"));
		String job_opening=request.getParameter("name");
		String profile=request.getParameter("profile");
		int no_of_openings=Integer.parseInt(request.getParameter("no_of_openings"));
		
		String date=request.getParameter("date");
	
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-mm-dd");
		  java.util.Date udob = null;
		try {
			udob = sdf.parse(date);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		  long ms=udob.getTime();
		  java.sql.Date  jobcalendar_date=new java.sql.Date(ms);
		
		  
		  String submitted_by=request.getParameter("submitted");
		
		
		JobCalender job_calender = new JobCalender(job_opening,profile,no_of_openings,jobcalendar_date,submitted_by);
		
		JobCalenderDAO aDao=new JobCalenderDAO();
		String result=aDao.insert(job_calender);
	 //   response.getWriter().print(result);
		if(result == "/JobCalenderSuccess.jsp") {
		RequestDispatcher dispatcher =
			       getServletContext().getRequestDispatcher(result);
			 dispatcher.forward(request, response);
			 }
		else {
			RequestDispatcher dispatcher =
				       getServletContext().getRequestDispatcher(result);
				 dispatcher.forward(request, response);
			
		}
	}
}