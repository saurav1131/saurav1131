package in.cdac.servlet;


import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import in.cdac.bean.CourseMaster;
import in.cdac.dao.CourseMasterDAO;

/**
 * Servlet implementation class UpdateServlet
 */
@WebServlet("/CourseMasterUpdateServlet")
public class CourseMasterUpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public CourseMasterUpdateServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int course_id =Integer.parseInt(request.getParameter("ucourse_id"));
		String course_name=request.getParameter("ucourse_name");
		String course_detail=request.getParameter("ucourse_detail");
		String course_batch=request.getParameter("ucourse_batch");
		//String submitted_by=request.getParameter("usubmitted");
		
		
	
	
	
	 // String submitted_by=request.getParameter("usubmitted");
		
		CourseMaster user =new CourseMaster(course_id,course_name,course_detail,course_batch);
		
		CourseMasterDAO aDao=new CourseMasterDAO();
		String result=aDao.update(user);
	    //response.getWriter().print(result);
		
		if(result == "/CourseMasterSuccessUpdate.jsp") {
			RequestDispatcher dispatcher =
				       getServletContext().getRequestDispatcher(result);
				 dispatcher.forward(request, response);
				 }
		else {
			RequestDispatcher dispatcher =
				       getServletContext().getRequestDispatcher(result);
					 dispatcher.forward(request, response);
				
			}
	
	}
	
	}