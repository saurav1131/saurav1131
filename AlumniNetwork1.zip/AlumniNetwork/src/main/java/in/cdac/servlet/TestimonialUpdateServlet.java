package in.cdac.servlet;


import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import in.cdac.bean.Testimonial;
import in.cdac.dao.TestimonialDAO;

/**
 * Servlet implementation class UpdateServlet
 */
@WebServlet("/TestimonialUpdateServlet")
public class TestimonialUpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public TestimonialUpdateServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int testimonial_id =Integer.parseInt(request.getParameter("uid"));
		String testimonial_text=request.getParameter("utext");
		String testimonial_type=request.getParameter("utype");
		String filepath=request.getParameter("ufilepath");
		String status=request.getParameter("ustatus");
	
		//String submitted_by=request.getParameter("usubmitted");
		
		
	
	
	
	 // String submitted_by=request.getParameter("usubmitted");
		
		Testimonial user =new Testimonial(testimonial_id,testimonial_text,testimonial_type,filepath,status);
		
		TestimonialDAO aDao=new TestimonialDAO  ();
		String result=aDao.update(user);
	    //response.getWriter().print(result);
		
		if(result == "/TestimonialSuccessUpdate.jsp") {
			RequestDispatcher dispatcher =
				       getServletContext().getRequestDispatcher(result);
				 dispatcher.forward(request, response);
				 }
		else {
			RequestDispatcher dispatcher =
				       getServletContext().getRequestDispatcher(result);
					 dispatcher.forward(request, response);
				
			}
	
	}
	
	}