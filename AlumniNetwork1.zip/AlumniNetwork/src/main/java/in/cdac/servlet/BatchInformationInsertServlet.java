package in.cdac.servlet;


//import java.sql.Connection;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import in.cdac.bean.BatchInformation;
import in.cdac.dao.BatchInformationDAO;

/**
 * Servlet implementation class AnnouncementServlet
 */
@WebServlet("/BatchInformationInsertServlet")
public class BatchInformationInsertServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BatchInformationInsertServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		String batch_name=request.getParameter("name");	
	  String start_date=request.getParameter("start_date");
	 
	  
	  //String start_date=request.getParameter("start_date");
	  SimpleDateFormat sdf=new SimpleDateFormat("yyyy-mm-dd");
	  java.util.Date udob = null;
	try {
		udob = sdf.parse(start_date);
	} catch (ParseException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	  long ms=udob.getTime();
	  java.sql.Date batch_start_date=new java.sql.Date(ms);

		
		
		
	  String end_date=request.getParameter("end_date");

	  java.util.Date udob1 = null;
	try {
		udob1 = sdf.parse(end_date);
	} catch (ParseException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	  long ms1=udob1.getTime();
	  java.sql.Date batch_end_date=new java.sql.Date(ms1);
	  
	  String status=request.getParameter("status");	                                                                                                                                                                                                                                                                                
	String submitted_by=request.getParameter("submitted");
	
		
		
		BatchInformation user =new BatchInformation (batch_name,batch_start_date,batch_end_date,status,submitted_by);
		

		BatchInformationDAO aDao=new BatchInformationDAO();
		String result=aDao.insert(user);
	 //   response.getWriter().print(result);
		if(result == "/Success.jsp") {
		RequestDispatcher dispatcher =
			       getServletContext().getRequestDispatcher(result);
			 dispatcher.forward(request, response);
			 }
		else {
			RequestDispatcher dispatcher =
				       getServletContext().getRequestDispatcher(result);
				 dispatcher.forward(request, response);
			
		}
	}
          
	}