package in.cdac.servlet;


import java.io.IOException;


import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import in.cdac.bean.Placementdetails;
import in.cdac.dao.PlacementdetailsDAO;

/**
 * Servlet implementation class AnnouncementServlet
 */
@WebServlet("/PlacementdetailsInsertServlet")
public class PlacementdetailsInsertServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PlacementdetailsInsertServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException,NumberFormatException{
		
		
		
		int batchid= Integer.parseInt(request.getParameter("idd"));
		String orgname=request.getParameter("name");
		String submitted_by=request.getParameter("submitted");
	
		
		
		Placementdetails placementdetails =new Placementdetails(batchid,orgname,submitted_by);
		
		PlacementdetailsDAO pDao=new PlacementdetailsDAO();
		String result=pDao.insert(placementdetails);
	 //   response.getWriter().print(result);
		if(result == "/PlacementdetailsSuccessInsert.jsp") {
		RequestDispatcher dispatcher =
			       getServletContext().getRequestDispatcher(result);
			 dispatcher.forward(request, response);
			 }
		else {
			RequestDispatcher dispatcher =
				       getServletContext().getRequestDispatcher("/PlacementdetailsInsertError.jsp");
				 dispatcher.forward(request, response);
			
		}
	}
          
	}
