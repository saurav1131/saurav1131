package in.cdac.servlet;

import in.cdac.bean.*;
import java.io.IOException;
import in.cdac.dao.*;


import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//import in.cdac.dao.PortfolioDao;

/**
 * Servlet implementation class portfolio
 */
@WebServlet("/PortfolioInsertServlet")
public class PortfolioInsertServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	

       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PortfolioInsertServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		String name=request.getParameter("name");
		String photo_id=request.getParameter("photo_id");
		String personaldetails=request.getParameter("personaldetails");
		String qualification=request.getParameter("qualification");
		String projects=request.getParameter("projects");
		String certification=request.getParameter("certification");
		String paperspublished=request.getParameter("paperspublished");
		String location=request.getParameter("location");
		
		String submitted_by=request.getParameter("submitted_by");
	
		

		
		Portfolio user =new Portfolio(name,photo_id,personaldetails,qualification,projects,certification,paperspublished,location,submitted_by);
		
		PortfolioDao jDao=new PortfolioDao();
		String result=jDao.insert(user);
	 //   response.getWriter().print(result);
		if(result == "/PortfolioSuccess.jsp") {
		RequestDispatcher dispatcher =
			       getServletContext().getRequestDispatcher(result);
			 dispatcher.forward(request, response);
			 }
		else {
			RequestDispatcher dispatcher =
				       getServletContext().getRequestDispatcher(result);
				 dispatcher.forward(request, response);
			
		}
	}
          
	}