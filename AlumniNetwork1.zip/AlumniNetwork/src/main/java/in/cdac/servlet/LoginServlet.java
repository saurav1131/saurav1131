package in.cdac.servlet;

import java.io.IOException;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import in.cdac.bean.LoginBean;
import in.cdac.dao.RatingreviewLoginDao;

//import net.javaguides.login.bean.LoginBean;
//import net.javaguides.login.database.LoginDao;



@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1 ;
    private RatingreviewLoginDao loginDao;

    public void init() {
        loginDao = new RatingreviewLoginDao();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {

        String user_rollno = request.getParameter("rollnumber");
        String password = request.getParameter("password");
        LoginBean loginBean = new LoginBean();
        loginBean.setRollno(user_rollno);
        loginBean.setPassword(password);

        try {
            if (loginDao.validate(loginBean)) {
                //HttpSession session = request.getSession();
                // session.setAttribute("username",username);
                response.sendRedirect("MainHome.jsp");
            } else {
                HttpSession session = request.getSession();
                response.sendRedirect("LoginError.jsp");
                //session.setAttribute("user", username);
                //response.sendRedirect("login.jsp");
            }
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}