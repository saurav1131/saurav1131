package example.bean;
import java.io.IOException;


import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



/**
 * Servlet implementation class UpdateServlet
 */
@WebServlet("/PortfolioUpdateServlet")
public class PortfolioUpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public PortfolioUpdateServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int portfolio_id =Integer.parseInt(request.getParameter("uportfolio_id"));
		String name=request.getParameter("uname");
		String photo_id=request.getParameter("uphoto_id");
		String personaldetails=request.getParameter("upersonaldetails");
		String qualification=request.getParameter("uqualification");
		String projects=request.getParameter("uprojects");
		String certification=request.getParameter("ucertification");
		String paperspublished=request.getParameter("upaperspublished");
		String location=request.getParameter("ulocation");
	//	String submitted_by=request.getParameter("usubmitte_by");
		
		
	
	  //String submitted_by=request.getParameter("usubmitted");
		
		Portfolio user =new Portfolio(portfolio_id,name,photo_id,personaldetails,qualification,projects,certification,paperspublished,location);
		
		PortfolioDao jDao=new PortfolioDao();
		String result=jDao.update(user);
	    //response.getWriter().print(result);
		
		if(result == "/PortfolioUpdateSuccess.jsp") {
			RequestDispatcher dispatcher =
				       getServletContext().getRequestDispatcher(result);
				 dispatcher.forward(request, response);
				 }
	//		else {
		//		RequestDispatcher dispatcher =
			//		       getServletContext().getRequestDispatcher(result);
				//	 dispatcher.forward(request, response);
				
	//		}
	//
	}
	
	}