package in.cdac.servlet;


import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import in.cdac.bean.BatchInformation;
import in.cdac.dao.BatchInformationDAO;

/**
 * Servlet implementation class BatchInformationUpdateServlet
 */
@WebServlet("/BatchInformationUpdateServlet")
public class BatchInformationUpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public BatchInformationUpdateServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int batch_id =Integer.parseInt(request.getParameter("uid"));
		String batch_name=request.getParameter("uname");
	
		
		
	  String batch_start_date=request.getParameter("ustart_date");
	  SimpleDateFormat sdf=new SimpleDateFormat("yyyy-mm-dd");
	  java.util.Date udob = null;
	try {
		udob = sdf.parse(batch_start_date);
	} catch (ParseException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	  long ms=udob.getTime();
	  java.sql.Date start_date=new java.sql.Date(ms);

		
		
		
	  String batch_end_date=request.getParameter("uend_date");
	  String status=request.getParameter("ustatus");
	  java.util.Date udob1 = null;
	try {
		udob1 = sdf.parse(batch_end_date);
	} catch (ParseException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	  long ms1=udob1.getTime();
	  java.sql.Date end_date=new java.sql.Date(ms1);
	
	
	 // String submitted_by=request.getParameter("usubmitted");
		
	  String submitted_by=request.getParameter("submitted");
	BatchInformation user =new BatchInformation (batch_name,start_date,end_date,status,submitted_by);
	  BatchInformationDAO	 aDao=new BatchInformationDAO();
		String result=aDao.update(user);
	    //response.getWriter().print(result);
		
		if(result == "/BatchInformationSuccessUpdate.jsp") {
			RequestDispatcher dispatcher =
				       getServletContext().getRequestDispatcher(result);
				 dispatcher.forward(request, response);
				 }
			else {
				RequestDispatcher dispatcher =
					       getServletContext().getRequestDispatcher(result);
					 dispatcher.forward(request, response);
				
			}
	
	}
	
	}