package in.cdac.servlet;



import java.io.IOException;


import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import in.cdac.bean.RatingAndReview;
import in.cdac.dao.RatingAndReviewDAO;



/**
 * Servlet implementation class UpdateServlet
 */
@WebServlet("/RatingReviewUpdateServlet")
public class RatingReviewUpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public RatingReviewUpdateServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int review_id =Integer.parseInt(request.getParameter("uid"));
		String review_text=request.getParameter("utext");
		int overall_rating=Integer.parseInt(request.getParameter("urating"));
		
		
	
	  //String submitted_by=request.getParameter("usubmitted");
		
		RatingAndReview user =new RatingAndReview(review_id,review_text,overall_rating);
		
		RatingAndReviewDAO jDao=new RatingAndReviewDAO();
		String result=jDao.update(user);
	    //response.getWriter().print(result);
		
		if(result == "/RatingReviewUpdateSuccess.jsp") {
			RequestDispatcher dispatcher =
				       getServletContext().getRequestDispatcher(result);
				 dispatcher.forward(request, response);
				 }
//			else {
//				RequestDispatcher dispatcher =
//					       getServletContext().getRequestDispatcher(result);
//					 dispatcher.forward(request, response);
//				
//			}
//	
	}
	
	}
