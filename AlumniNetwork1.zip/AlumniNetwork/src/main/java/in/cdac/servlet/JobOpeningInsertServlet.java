package in.cdac.servlet;
import in.cdac.bean.JobOpening;

import in.cdac.dao.JobopeningDAO;

import java.io.IOException;


import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class AnnouncementServlet
 */
@WebServlet("/JobOpeningInsertServlet")
public class JobOpeningInsertServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public JobOpeningInsertServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		String job_name=request.getParameter("name");
		String job_description=request.getParameter("description");
		String job_eligibility=request.getParameter("eligibility");
		String submitted_by=request.getParameter("submitted");
	
		
		
		JobOpening user =new JobOpening(job_name,job_description,job_eligibility,submitted_by);
		
		JobopeningDAO jDao=new JobopeningDAO();
		String result=jDao.insert(user);
	 //   response.getWriter().print(result);
		if(result == "/JobInsertSuccess.jsp") {
		RequestDispatcher dispatcher =
			       getServletContext().getRequestDispatcher(result);
			 dispatcher.forward(request, response);
			 }
		else {
			RequestDispatcher dispatcher =
				       getServletContext().getRequestDispatcher(result);
				 dispatcher.forward(request, response);
			
		}
	}
          
	}