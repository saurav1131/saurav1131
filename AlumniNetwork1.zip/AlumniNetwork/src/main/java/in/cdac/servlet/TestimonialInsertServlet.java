package in.cdac.servlet;



import java.io.IOException;


import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import in.cdac.bean.Testimonial;
import in.cdac.dao.TestimonialDAO;

/**
 * Servlet implementation class TestimonialServlet
 */
@WebServlet("/TestimonialInsertServlet")
public class TestimonialInsertServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TestimonialInsertServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		String testimonial_text=request.getParameter("text");
		String testimonial_type=request.getParameter("type");
		String filepath=request.getParameter("filepath");
		String status=request.getParameter("status");
		String submitted_by=request.getParameter("submitted");
	
		
		
		Testimonial user =new Testimonial(testimonial_text,testimonial_type,filepath,status,submitted_by);
		
		TestimonialDAO tDao=new TestimonialDAO();
		String result=tDao.insert(user);
	 //   response.getWriter().print(result);
		if(result == "/TestimonialInsertSuccess.jsp") {
		RequestDispatcher dispatcher =
			       getServletContext().getRequestDispatcher(result);
			 dispatcher.forward(request, response);
			 }
		else {
			RequestDispatcher dispatcher =
				       getServletContext().getRequestDispatcher(result);
				 dispatcher.forward(request, response);
			
		}
	}
          
	}