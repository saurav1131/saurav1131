package in.cdac.servlet;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import in.cdac.bean.JobCalender;
import in.cdac.dao.JobCalenderDAO;

/**
 * Servlet implementation class UpdateServlet
 */
@WebServlet("/JobCalenderUpdateServlet")
public class JobCalenderUpdateServlet extends HttpServlet
{
	private static final long serialVersionUID = 1L;
       
    
    public JobCalenderUpdateServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int job_id =Integer.parseInt(request.getParameter("id"));
		String job_opening=request.getParameter("name");
		String profile=request.getParameter("profile");
		int no_of_openings=Integer.parseInt(request.getParameter("no of openings"));
	    String date=request.getParameter("date");
	  SimpleDateFormat sdf=new SimpleDateFormat("yyyy-mm-dd");
	  java.util.Date udob = null;
	  
	try {
		udob = sdf.parse(date);
	} catch (ParseException e)
	{
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	  long ms=udob.getTime();
	  java.sql.Date jobcalendar_date=new java.sql.Date(ms);
	 
	 // String submitted_by=request.getParameter("sbmitted");
	
		
	  JobCalender job_calender =new JobCalender(job_id,job_opening,profile,no_of_openings, jobcalendar_date );
		
		JobCalenderDAO aDao=new JobCalenderDAO();
		String result=aDao.update(job_calender);
	    //response.getWriter().print(result);
		
		if(result == "JobCalenderUpdateSuccess.jsp")
		{
			RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(result);
				 dispatcher.forward(request, response);
				 }
	}}
//			else {
//				RequestDispatcher dispatcher =
//					       getServletContext().getRequestDispatcher(result);
//					 dispatcher.forward(request, response);
//				
//			}
//